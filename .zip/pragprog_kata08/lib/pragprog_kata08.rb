require 'pragprog_kata08/trie'
require 'pragprog_kata08/runner'

module PragprogKata08
end
