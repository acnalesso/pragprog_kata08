# PragprogKata08

----------------

See these for more info.
http://codekata.pragprog.com/2007/01/kata_eight_conf.html
http://en.wikipedia.org/wiki/Radix_tree

## Purpose
It uses a PATRICIA Trie or a Radix Trie like to add words values to
its buckets.
By doing this we can minimize look up time, improve speed.


## Installation

Add this line to your application's Gemfile:

    gem 'pragprog_kata08'

And then execute:

    $ bundle

Or install it yourself as:

    $ gem install pragprog_kata08

## Usage

```
trie = PragprogKata08::Trie.new
trie.insert("ruby")
trie.find("ruby")
#=> ["rub", "y"]

trie.insert("rubicon")
trie.find("rub")
#=> ["rub"]
```

## Rake

```
rake run
or
rake
```

What if you want to use a list of your own?
```
rake run path="path_to_my_list"
```
## Contributing

1. Fork it
2. Create your feature branch (`git checkout -b my-new-feature`)
3. Commit your changes (`git commit -am 'Add some feature'`)
4. Push to the branch (`git push origin my-new-feature`)
5. Create new Pull Request
